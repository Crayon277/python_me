python
======
学习Python时的代码





####2016-03-20 update 

[Machine Learning with Python](https://github.com/xxg1413/MachineLearning)  
- [Building Machine Learning Systems](https://github.com/xxg1413/MachineLearning/tree/master/Building%20Machine%20Learning%20Systems)
- [CS229 Machine Learning](https://github.com/xxg1413/MachineLearning/tree/master/CS229%20Machine%20Learning)
- [Machine Learning in Action](https://github.com/xxg1413/MachineLearning/tree/master/Machine%20Learning%20in%20Action)
- [NumPy Beginner's Guide](https://github.com/xxg1413/MachineLearning/tree/master/NumPy%20Beginner's%20Guide)
- [Web Scraping with Python](https://github.com/xxg1413/MachineLearning/tree/master/Web%20Scraping%20with%20Python)



