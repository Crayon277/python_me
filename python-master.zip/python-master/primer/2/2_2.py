a = '19'
print "please input a int number in 1-100"
x = raw_input()
if a != x:
    print "sorry you are wrong!\ninput again:"
    x = raw_input()
else
   print "you are right"
raw_input()
