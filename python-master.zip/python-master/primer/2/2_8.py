s=[1,2,3,4,5,6]
i = 0
t = 0
for i in s:
    t += i
print float(t)/len(s)
raw_input()
