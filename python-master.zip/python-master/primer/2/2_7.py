s = raw_input()
i = 0
for i in s:
    print i
raw_input()
