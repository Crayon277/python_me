#!/usr/bin/python
#-*- coding: utf-8 -*-
# File Name: setup.py
# Created Time: Sun Oct  9 22:53:30 2016

__author__ = 'Crayon Chaney <mmmmmcclxxvii@gmail.com>'

from distutils.core import setup

setup(
        name = 'printList',
        version = '1.1.0',
        py_modules = ['printList'],
        author = 'mmmmmcclxxvii',
        author_email = 'mmmmmcclxxvii@gmail.com',
        url = 'http://www.mmmmmcclxxvii.cn',
        description = 'Test. head first python.',

        )
