#!/usr/bin/env python

import Tkinter

top = Tkinter.Tk()
label = Tkinter.Label(top, text = 'Hello world!')
label.pack()
Tkinter.mainloop()